#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

if [ "$(id -u)" -ne 0 ]; then
  echo "Please run with sudo: sudo ./build.sh" >&2
  exit 1
fi

if ! command -v lb >/dev/null 2>&1; then
  echo "live-build is missing. Install it with: apt install live-build" >&2
  exit 1
fi

echo "Configuring BudgieOS 1.0..."
lb config
echo "Building BudgieOS 1.0 (this may take a while)..."
lb build

echo
echo "Build finished. Generated ISO files:"
find . -maxdepth 1 -type f -name '*.iso' -printf '%f\n'
