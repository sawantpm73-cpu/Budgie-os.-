# BudgieOS 1.0 — Debian Live Build project

This is a **buildable starting project**, not a prebuilt ISO. It creates a Debian
Live image with an XFCE desktop, a BudgieOS pastel theme, common desktop tools,
and a BudgieOS wallpaper. It does not yet reproduce every feature from the
concept mockup, and it does not include proprietary Windows/macOS components.

## Build requirements

- A Debian 13 (trixie) or compatible Debian build environment
- `live-build`, `debootstrap`, `squashfs-tools`, `xorriso`, `dosfstools`
- Internet access and several GB of free disk space
- For a full desktop ISO, allow roughly 15–25 GB of working space

## Build on Debian

From this directory, run:

```bash
sudo apt update
sudo apt install -y live-build
sudo ./build.sh
```

The ISO should be created in this directory if the build completes. The exact
filename is printed by the script. Build time and image size depend on network
speed and the Debian mirror.

## Notes

- Default architecture is `amd64` (64-bit Intel/AMD PCs).
- The desktop is XFCE themed for BudgieOS; this is not the upstream Budgie
  desktop environment.
- Firefox ESR and LibreOffice are included. Steam, Roblox, and Microsoft 365
  are not bundled; availability depends on hardware, region, accounts, and
  third-party compatibility.
- Test the ISO in a virtual machine before installing it on a physical PC.
- This project does not modify your existing Windows installation.
