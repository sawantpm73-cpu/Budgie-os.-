BudgieOS wallpaper location.
Replace this file with your own wallpaper image named budgieos-wallpaper.png.
